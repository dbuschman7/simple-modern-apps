# Infrastructure

## Common resources use in multiple places

* state store in S3 bucket
* setup AWS Lambdas role and cloud watch access and logging
* setup ECR repos for all lambda to to publish images into
