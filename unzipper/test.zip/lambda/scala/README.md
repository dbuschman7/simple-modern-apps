# Install scala-cli

NOTE: NO use of sbt here, keep it simple

``` shell
brew install virtuslab/scala-cli/scala-cli
```

Must use Java 17 only, 12 is not supported yet

``` shell 
sdk use java 17.0.8.fx-zulu
```
